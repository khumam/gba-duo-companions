// Writes layout.json for the "Minish-OS bezel" design: a notched stone frame (rupees top
// left, kinstones top right, the page's title tab on top, Ezlo on the left rail, the A and B
// items on the right rail) around one content area. The two bottom corners are the nav: they
// walk the five pages as a loop (previous on the left, next on the right), so each page
// carries its own pair.
//
//   node art/layout.mjs

import fs from "node:fs";

const box = (cls, children, extra = {}) => ({ type: "box", class: cls, children, ...extra });
const text = (cls, t, extra = {}) => ({ type: "text", class: cls, text: t, ...extra });
const img = (cls, src, extra = {}) => ({ type: "image", class: cls, src, ...extra });
const button = (cls, onClick, children) => ({ type: "button", class: cls, onClick, children });
const list = (cls, items, template, extra = {}) => ({ type: "list", class: cls, items, template, ...extra });
const bar = (cls, value) => ({ type: "bar", class: cls, value, max: 1 });
const ui = (n) => `asset:ui/${n}.png`;
// Icons come from main.lua (`icons.*`): drawn from the player's ROM, or the pack's own art.
const ICON_KEYS = {
  "kinstone-red": "kinstoneRed", "kinstone-blue": "kinstoneBlue", "kinstone-green": "kinstoneGreen",
  "kinstone-gold": "kinstoneGold", figurines: "figurines", "tiger-scroll": "tigerScroll",
  "heart-piece": "heartPiece", shell: "shell", bombs: "bombs", quiver: "quiver", "farores-charm": "charm",
};
const icon = (n) => {
  if (!ICON_KEYS[n]) throw new Error(`no icon key for ${n}`);
  return `$icons.${ICON_KEYS[n]}`;
};
const grow = () => box("grow", []);

// ---- frame: rails, corners, stats, Ezlo, A / B --------------------------------------------

const rail = (side) =>
  box(`rail rail-${side}`, [box(`rail-band rail-band-${side}`, []), box("rail-band-bot", [])]);
const corner = (pos) => img(`corner corner-${pos}`, ui(`corner-${pos}`));

const statLeft = box("stat-corner stat-tl", [
  img("hicon hicon-rupee", ui("rupee-green")),
  box("stat-col", [text("num rupees", "{rupees}"), text("num of", "/{walletMax}")]),
]);
const statRight = box("stat-corner stat-tr", [
  img("hicon", icon("kinstone-red")),
  text("num kin", "{kinstones}"),
]);

const ezlo = button("ezlo-btn", [{ set: { hint: true } }], [img("ezlo", "$ezlo")]);

const equip = (key, path) =>
  box(`equip equip-${key.toLowerCase()}`, [
    box("equip-ring", [img("equip-icon", `$${path}.icon`), box("equip-badge", [text("equip-key", key)])]),
    text("equip-name", `{${path}.name}`),
  ]);

const hint = box(
  "bubble",
  [
    img("bubble-ezlo", "$ezlo"),
    box("bubble-body", [
      text("bubble-name", "EZLO"),
      text("bubble-text", "{ezloHint}"),
      text("bubble-close", "TAP TO CLOSE"),
    ]),
  ],
  { visibleIf: "$ui.hint", onClick: [{ set: { hint: false } }] },
);

const equipBtn = (cls, label, button) =>
  box(`menu-btn ${cls}`.trim(), [text("menu-btn-text", label)], { onClick: { call: "equip", args: [button, "{ui.menu}"] } });
const equipMenu = box(
  "equip-menu",
  [
    box("menu-head", [img("menu-icon", "$ui.menuIcon"), text("menu-name", "{ui.menuName}")]),
    box("menu-row", [equipBtn("", "A BUTTON", "A"), equipBtn("", "B BUTTON", "B")]),
    box("menu-btn menu-cancel", [text("menu-btn-text", "CANCEL")], { onClick: { set: { menu: "" } } }),
  ],
  { visibleIf: "$ui.menu" },
);

// ---- page chrome: title tab and the two nav corners -----------------------------------------

const ORDER = ["map", "items", "kinstone", "quest", "options"];
const TITLES = { map: "MAPS", items: "ITEMS", kinstone: "KINSTONE", quest: "QUESTS", options: "OPTIONS" };

const titleTab = (name) =>
  box("title-row", [
    box("title-tab", [text("title-text", TITLES[name])]),
  ]);

const navCorner = (side, target) =>
  button(`nav nav-${side}`, [{ navigate: target }], [
    text(`nav-label nav-label-${side}`, TITLES[target]),
    ...(target === "kinstone" ? [img(`nav-alert nav-alert-${side}`, icon("kinstone-red"), { visibleIf: "$kinstone.ready" })] : []),
  ]);
const nav = (name) => {
  const i = ORDER.indexOf(name);
  return [navCorner("l", ORDER[(i + ORDER.length - 1) % ORDER.length]), navCorner("r", ORDER[(i + 1) % ORDER.length])];
};

// ---- panels -------------------------------------------------------------------------------

// Copper rim around a wooden inset.
const panel = (cls, inner) => box(`pframe ${cls}`, [box("pinner", inner)]);
const card = (cls, title, body) =>
  box(`card ${cls}`, [...(title ? [text("card-title", title)] : []), ...body]);

// An item slot; tapping copies it into $ui.pick*.
const pick = [{ set: { pick: "{name}", pickIcon: "{icon}", picked: true, menu: "{equipKey}", menuName: "{name}", menuIcon: "{icon}" } }];
const slot = (cls = "") =>
  box(
    `slot ${cls}`.trim(),
    [
      img("slot-icon", "$icon", { visibleIf: "$owned" }),
      box("slot-count", [text("num count", "{count}")], { visibleIf: "$hasCount" }),
    ],
    { classIf: { empty: "$empty" }, onClick: pick },
  );
const picked = (cls = "") =>
  box(
    `picked ${cls}`.trim(),
    [img("picked-icon", "$ui.pickIcon"), text("picked-name", "{ui.pick}")],
    { visibleIf: "$ui.picked" },
  );

// ---- map page -----------------------------------------------------------------------------

const mapTab = (label, worldAt, on) => ({
  type: "button",
  class: "map-tab",
  onClick: [{ set: { mapWorldAt: worldAt } }],
  classIf: { on },
  children: [text("map-tab-label", label)],
});

// The dungeon you're in: its floors (Link's, and the boss's once you have the compass),
// then the map, compass and big key (dimmed until found) and the small keys, drawn
// with the pause menu's own sprites.
const dungeonView = box(
  "dmap",
  [
    box("dmap-head", [text("dmap-name", "{dungeon.name}")]),
    box("dmap-body", [
      list(
        "dmap-floors",
        "$dungeon.floors",
        box(
          "dfloor",
          [
            box("dfloor-mark", [img("dfloor-link", "$icons.linkHead", { visibleIf: "$here" })]),
            text("num dfloor-name", "{name}"),
            box("dfloor-mark", [img("dfloor-boss", ui("mark-boss"), { visibleIf: "$boss" })]),
          ],
          { classIf: { here: "$here" } },
        ),
      ),
      box("dmap-items", [
        list(
          "ditem-row",
          "$dungeon.items",
          box("ditem", [box("ditem-slot", [img("ditem-icon", "$icon")]), text("ditem-name", "{name}")], {
            classIf: { missing: "$missing" },
          }),
        ),
        box("dkeys", [img("dkey-icon", "$dungeon.keyIcon"), text("num dkey-num", "{dungeon.keys}")]),
      ]),
    ]),
  ],
  { visibleIf: "$map.showDungeon" },
);

const mapPage = box("content", [
  panel("p-map", [
    box("map-row", [
      box("map-view", [
        // The game's own world map, built from the player's ROM by main.lua (or the drawn fallback).
        img("map-img", "$map.image"),
        img("mark mark-link", "$icons.linkHead", { bindStyle: { left: "{map.linkX}%", top: "{map.linkY}%" } }),
        dungeonView,
      ]),
      box("map-info", [
        box("map-tag", [text("map-tag-text", "{location}")]),
        // In a dungeon: WORLD / DUNGEON. WORLD keeps the visit it was tapped in, so the
        // next dungeon opens on DUNGEON again (main.lua readDungeonMap).
        box("map-tabs", [
          mapTab("WORLD", "{map.visit}", "$map.showWorld"),
          mapTab("DUNGEON", "", "$map.showDungeon"),
        ], { visibleIf: "$map.inDungeon" }),
      ]),
    ]),
  ]),
  // Link and his hearts, as the game draws them (rom_gfx.lua), following his health.
  panel("p-link", [
    box("link-row", [
      img("link-sprite", "$link.sprite"),
      box("link-info", [
        text("link-caption", "LINK'S HEARTS"),
        list("hearts", "$link.hearts", img("heart", "$src"), { visibleIf: "$link.hasHearts" }),
      ]),
    ]),
  ]),
]);

// ---- items page ---------------------------------------------------------------------------

const gearRow = (iconName, name, val, pct, cls) =>
  box(`gear-row ${cls}`, [
    img("gear-icon", icon(iconName)),
    box("gear-main", [
      box("gear-top", [text("gear-name", name), grow(), text("num gear-val", val)]),
      ...(pct ? [bar("gear-bar", pct)] : []),
    ]),
  ]);
const itemsPage = box("content", [
  panel("p-pouch", [
    box("pouch-head", [text("pouch-title", "TAP AN ITEM"), picked()]),
    list("item-grid", "$items", slot("slot-s")),
  ]),
  panel("p-gear", [
    box("gear-grid", [
      gearRow("bombs", "BOMBS", "{gear.bombs}/{gear.bombMax}", "$gear.bombPct", "red"),
      gearRow("quiver", "ARROWS", "{gear.arrows}/{gear.arrowMax}", "$gear.arrowPct", "blue"),
      gearRow("farores-charm", "CHARM", "{gear.charmTime}", null, ""),
      gearRow("shell", "SHELLS", "{gear.shells}", null, ""),
      gearRow("heart-piece", "PIECES", "{gear.heartPieces}", null, "gear-wide"),
    ]),
  ]),
]);

// ---- kinstone page ------------------------------------------------------------------------

const kinstonePage = box("content", [
  panel("p-pieces", [
    list(
      "piece-grid",
      "$kinstone.pieces",
      box(
        "piece",
        [
          img("piece-icon", "$icon"),
          box("piece-text", [
            text("piece-name", "{name}"),
            box("piece-foot", [text("num piece-id", "{id}"), grow(), text("num piece-amt", "{amount}")]),
          ]),
        ],
        { classIf: { red: "$isRed", blue: "$isBlue", green: "$isGreen", gold: "$isGold" } },
      ),
      { empty: "NO KINSTONE PIECES YET" },
    ),
  ]),
  panel("p-fusion", [
    box("fuse-count", [text("fuse-label", "FUSED"), grow(), text("num fuse-num", "{kinstone.fused}"), text("num fuse-of", "/{kinstone.fusionTotal}")]),
    bar("fuse-bar", "$kinstone.fusedPct"),
    box("tally", [
      box("tally-cell", [img("tally-icon", icon("kinstone-red")), text("num tally-num", "{kinstone.red}")]),
      box("tally-cell", [img("tally-icon", icon("kinstone-blue")), text("num tally-num", "{kinstone.blue}")]),
      box("tally-cell", [img("tally-icon", icon("kinstone-green")), text("num tally-num", "{kinstone.green}")]),
      box("tally-cell", [img("tally-icon", icon("kinstone-gold")), text("num tally-num", "{kinstone.gold}")]),
    ]),
    grow(),
    box("alert", [img("alert-icon", icon("kinstone-red")), text("alert-text", "{kinstone.readyHint}")], {
      visibleIf: "$kinstone.ready",
    }),
  ]),
]);

// ---- quest page ---------------------------------------------------------------------------

const questPage = box("content", [
  panel("p-quest", [
    box("quest-top", [
      card("dungeon-card", "DUNGEONS", [
        list(
          "dungeon-list",
          "$quest.dungeons",
          box(
            "dungeon",
            [
              box("dg-mark", [
                img("dg-check", ui("check"), { visibleIf: "$cleared" }),
                img("dg-here", "$icons.linkHead", { visibleIf: "$here" }),
              ]),
              text("dg-name", "{name}"),
            ],
            { classIf: { cleared: "$cleared", here: "$here" } },
          ),
        ),
      ]),
      box("quest-right", [
        list(
          "element-row",
          "$quest.elements",
          box("element", [img("element-icon", "$icon"), text("element-name", "{name}")], {
            classIf: { owned: "$owned", locked: "$locked" },
          }),
        ),
        box("stats", [
          box("stat", [img("stat-icon", icon("figurines")), text("num stat-val", "{quest.figurines}")]),
          box("stat", [img("stat-icon", icon("tiger-scroll")), text("num stat-val", "{quest.skills}")]),
        ]),
      ]),
    ]),
    text("side-caption", "SIDE QUESTS"),
    list(
      "side-list",
      "$quest.side",
      box("side", [img("side-icon", "$icon"), text("side-name", "{name}"), text("side-done", "DONE", { visibleIf: "$done" })], {
        classIf: { done: "$done" },
      }),
      { empty: "NO ERRANDS RIGHT NOW" },
    ),
  ]),
]);

// ---- options page -------------------------------------------------------------------------

// One switch per row; the app handles both calls itself (wideView steps off > on > XL, ambientView toggles).
const option = (title, desc, call, onKey, labelKey) =>
  button(
    "opt",
    call === "writePermission" ? { call } : { call, args: ["toggle"] },
    [
      box("opt-text", [text("opt-title", title), text("opt-desc", desc)]),
      box("opt-pill", [text("num opt-state", `{${labelKey}}`)], { classIf: { on: `$${onKey}` } }),
    ],
  );
const optionsPage = box("content", [
  panel("p-options", [
    box("opt-list", [
      option("WIDE VIEW", "Paint the world beyond the game's frame. Tap again for extra wide.", "wideView", "_wide", "_wideLabel"),
      option("COLOR AMBIENT", "A richer grade with soft shadows, sunlit edges and drifting clouds.", "ambientView", "_ambient", "_ambientLabel"),
      option("GAME CHANGES", "Lets this pack hide the game's own HUD and equip items. Tap to be asked again.", "writePermission", "_writePerm", "_writePermLabel"),
    ]),
  ]),
]);

// Content first, then the title tab and nav corners, so the corners' notches sit on top of it.
const page = (name, content) => ({ name, child: box(`page page-${name}`, [content, titleTab(name), ...nav(name)]) });

const layout = box(
  "bezel",
  [
    box("waiting", [
      box("boot", [
        img("boot-emblem", "$logo", { visibleIf: "$hasLogo" }),
        text("boot-title", "THE MINISH CAP", { visibleIf: "$noLogo" }),
        box("boot-pill", [text("boot-pill-text", "GBADUO COMPANION PACK")]),
      ]),
    ], { visibleIf: "$waiting" }),
    box("shell", [
      // The real engine only stretches a stack child when the stack's size is
      // definite, so the pages get a flex-sized wrapper and explicit 100% sizes.
      box("pages-wrap", [{
        type: "pages",
        class: "pages",
        pages: [page("map", mapPage), page("items", itemsPage), page("kinstone", kinstonePage), page("quest", questPage), page("options", optionsPage)],
      }]),
      rail("l"),
      rail("r"),
      corner("tl"),
      corner("tr"),
      statLeft,
      statRight,
      box("rail-slot rail-slot-l", [ezlo]),
      box("rail-slot rail-slot-r", [equip("A", "equipA"), equip("B", "equipB")]),
      hint,
      equipMenu,
    ], { visibleIf: "$ready" }),
  ],
  { id: "screen" },
);

fs.writeFileSync(new URL("../layout.json", import.meta.url), JSON.stringify(layout, null, 2) + "\n");
console.log("ok");
